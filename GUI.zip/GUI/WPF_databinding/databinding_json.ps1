﻿#region load assembly dlls

Add-Type -AssemblyName PresentationCore,PresentationFramework

#endregion load assembly dlls

#region Cleanup XAML

$XAML= [XML](Get-Content -Path "$PSScriptRoot\MainWindow_json.xaml" -Raw)
$XAML.Window.RemoveAttribute('x:Class')
$XAML.Window.RemoveAttribute('xmlns:local')
$XAML.Window.RemoveAttribute('xmlns:d')
$XAML.Window.RemoveAttribute('xmlns:mc')
$XAML.Window.RemoveAttribute('mc:Ignorable')

#endregion Cleanup XAML options

#region Add namespace manager to recognise x: tags
$XAMLreader = New-Object System.Xml.XmlNodeReader $XAML
$Rawform = [Windows.Markup.XamlReader]::Load($XAMLreader)

$XmlNamespaceManager = [System.Xml.XmlNamespaceManager]::New($XAML.NameTable)
$XmlNamespaceManager.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')

#endregion Add namespace manager to recognise x: tags

#region Create PS objects for controls

$Gui = @{}
$namedNodes = $XAML.SelectNodes("//*[@x:Name]",$XmlNamespaceManager)
$namedNodes | ForEach-Object -Process {$Gui.Add($_.Name, $Rawform.FindName($_.Name))}

#endregion Create PS objects for controls


#region buttons

$Gui.Get_childitem.Add_Click({
    If (!([string]::IsNullOrEmpty($Gui.Inputtext.text)))
    {
        $childitems = Get-ChildItem -Path $Gui.Inputtext.text -ErrorAction SilentlyContinue
        foreach ($item in $childitems)
        {
            $Gui.Itemlist.Items.Add($item.fullname)
        }
        $Gui.Inputtext.Clear()
    }
})

#endregion buttons

#region listboxes

$Gui.Itemlist.Add_Drop({
    $content = Get-Content $_.Data.GetFileDropList()
    $content | ForEach-Object -Process {
        $Gui.Itemlist.Items.Add($_)
    }
})


$Gui.Itemlist.Add_MouseDoubleClick({
    
        $Gui.Detaileditemlist.Items.clear()
        $itemproperties = Get-ItemProperty -Path $Gui.Itemlist.selecteditem -ErrorAction SilentlyContinue
        $itempropertiesnames =($itemproperties | Get-Member -MemberType Property -ErrorAction SilentlyContinue ).Name
        foreach ($item in $itempropertiesnames)
        {
            $Gui.Detaileditemlist.Items.Add($item + ": " + $itemproperties.$item)
        }
})

#endregion listboxes


#region create databinding

# Create a datacontext for the textbox and set it
$DataContext = New-Object System.Collections.ObjectModel.ObservableCollection[Object]
$DataContext.Add((Convertfrom-Json (Invoke-WebRequest -Uri "http://worldtimeapi.org/api/timezone/Europe/Amsterdam").content))
$Gui.timebox.DataContext = $DataContext
 
# Create and set a binding on the textbox object
$Binding = New-Object System.Windows.Data.Binding
$Binding.Path = "datetime"
$Binding.Mode = [System.Windows.Data.BindingMode]::OneWay
[void][System.Windows.Data.BindingOperations]::SetBinding($Gui.timebox,[System.Windows.Controls.TextBox]::TextProperty, $Binding)
 
#endregion create databinding

#region build timed async updates

$updateform = {

    $DataContext[0] = Convertfrom-Json (Invoke-WebRequest -Uri "http://worldtimeapi.org/api/timezone/Europe/Amsterdam").content

}

$rawform.add_sourceinitialized({
        #create timer object
        $timer = new-object System.Windows.Threading.DispatcherTimer
        $timer.interval = [timespan]"0:0:3"

        #add event per tick
        $timer.add_tick({

            &$updateform
            
        })

        #start timer
        $timer.start()
})

#endregion build timed async updates

#region Show the form

$showform = Read-Host -Prompt "Do you want to show the form now - $Rawform.ShowDialog() ? (Y / N)"

if ($showform -like "Y")
{
    $Rawform.ShowDialog()
}
#endregion Show the form