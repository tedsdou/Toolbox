﻿#region create Synchronised variables 

$global:Rawform = [hashtable]::Synchronized(@{})
$global:GUIRunspace = [hashtable]::Synchronized(@{})
$global:GUI = [hashtable]::Synchronized(@{})

#endregion Synchronise variables

#region create runspace

$PSScriptRoot
$GUIRunspace.psscriptroot = $PSScriptRoot
$GUIRunspace.runspace = [RunspaceFactory]::CreateRunspace()
$GUIRunspace.runspace.ApartmentState = “STA”
$GUIRunspace.runspace.ThreadOptions = “ReuseThread”
#open runspace
$GUIRunspace.runspace.Open()
$GUIRunspace.psCmd = {Add-Type -AssemblyName PresentationCore,PresentationFramework,WindowsBase}.GetPowerShell() 
$GUIRunspace.runspace.SessionStateProxy.SetVariable("Rawform",$Rawform)
$GUIRunspace.runspace.SessionStateProxy.SetVariable("GUIRunspace",$GUIRunspace)
$GUIRunspace.runspace.SessionStateProxy.SetVariable("GUI",$GUI)
$GUIRunspace.psCmd.Runspace = $GUIRunspace.runspace 

#endregion create runspace

#region Add normal WPF code to runspace and invoke

$GUIRunspace.Handle = $GUIRunspace.psCmd.AddScript({ 

#region WPF code same as before

#region load and Cleanup XAML

$XAML= [XML](Get-Content -Path "$($GUIRunspace.psscriptroot)\MainWindow.xaml" -Raw)
$XAML.Window.RemoveAttribute('x:Class')
$XAML.Window.RemoveAttribute('xmlns:local')
$XAML.Window.RemoveAttribute('xmlns:d')
$XAML.Window.RemoveAttribute('xmlns:mc')
$XAML.Window.RemoveAttribute('mc:Ignorable')

#endregion load and Cleanup XAML options

#region Add namespace manager to recognise x: tags
$XAMLreader = New-Object System.Xml.XmlNodeReader $XAML
$Rawform.xaml = [Windows.Markup.XamlReader]::Load($XAMLreader)

$XmlNamespaceManager = [System.Xml.XmlNamespaceManager]::New($XAML.NameTable)
$XmlNamespaceManager.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')

#endregion Add namespace manager to recognise x: tags

#region Create PS objects for controls

$GUI.ui = @{}
$namedNodes = $XAML.SelectNodes("//*[@x:Name]",$XmlNamespaceManager)
$namedNodes | ForEach-Object -Process {$GUI.ui.Add($_.Name, $Rawform.xaml.FindName($_.Name))}

#endregion Create PS objects for controls

#region buttons

$GUI.ui.Get_childitem.Add_Click({
    If (!([string]::IsNullOrEmpty($GUI.ui.Inputtext.text)))
    {
        $childitems = Get-ChildItem -Path $GUI.ui.Inputtext.text -ErrorAction SilentlyContinue
        foreach ($item in $childitems)
        {
            $GUI.ui.Itemlist.Items.Add($item.fullname)
        }
        $GUI.ui.Inputtext.Clear()
    }
})

#endregion buttons

#region listboxes

$GUI.ui.Itemlist.Add_Drop({
    $content = Get-Content $_.Data.GetFileDropList()
    $content | ForEach-Object -Process {
        $GUI.ui.Itemlist.Items.Add($_)
    }
})

$GUI.ui.Itemlist.Add_MouseDoubleClick({
    
        $GUI.ui.Detaileditemlist.Items.clear()
        $itemproperties = Get-ItemProperty -Path $GUI.ui.Itemlist.selecteditem -ErrorAction SilentlyContinue
        $itempropertiesnames =($itemproperties | Get-Member -MemberType Property -ErrorAction SilentlyContinue ).Name
        foreach ($item in $itempropertiesnames)
        {
            $GUI.ui.Detaileditemlist.Items.Add($item + ": " + $itemproperties.$item)
        }
})

#endregion listboxes

#region Show the form

$Rawform.xaml.ShowDialog()

#endregion Show the form

#endregion WPF code same as before

}).BeginInvoke()

#endregion Add normal WPF code to runspace and invoke

#give runspace time to initialise
start-sleep -s 2

#region run code in normal PS shell that would otherwise freeze the form 

write-host "Code running in main PS window not freezing form"
write-host "start sleeping 10 sec $(get-date)"
start-sleep -s 10

#update form with calculated value
$OSlocation1 = (Get-WmiObject win32_operatingsystem -ComputerName localhost).SystemDirectory
$gui.ui.loc1.Dispatcher.Invoke({$gui.ui.loc1.Text = $OSlocation1})
$OSlocation1
start-sleep -s 5
$OSlocation2 = (Get-WmiObject win32_operatingsystem -ComputerName localhost).SystemDirectory
$gui.ui.loc2.Dispatcher.Invoke({$gui.ui.loc2.Text = $OSlocation2})
$OSlocation2
start-sleep -s 10
$OSlocation3 = (Get-WmiObject win32_operatingsystem -ComputerName localhost).SystemDirectory
$gui.ui.loc3.Dispatcher.Invoke({$gui.ui.loc3.Text = $OSlocation3})
$OSlocation3
write-host "end sleep $(get-date)"


#endregion run code in normal PS shell that would otherwise freeze the form