﻿#region load assembly dlls

Add-Type -AssemblyName PresentationCore,PresentationFramework

#endregion load assembly dlls

#region Cleanup XAML

$XAML= [XML](Get-Content -Path "$PSScriptRoot\MainWindow.xaml" -Raw)
$XAML.Window.RemoveAttribute('x:Class')
$XAML.Window.RemoveAttribute('xmlns:local')
$XAML.Window.RemoveAttribute('xmlns:d')
$XAML.Window.RemoveAttribute('xmlns:mc')
$XAML.Window.RemoveAttribute('mc:Ignorable')

#endregion Cleanup XAML options

#region Add namespace manager to recognise x: tags
$XAMLreader = New-Object System.Xml.XmlNodeReader $XAML
$Rawform = [Windows.Markup.XamlReader]::Load($XAMLreader)

$XmlNamespaceManager = [System.Xml.XmlNamespaceManager]::New($XAML.NameTable)
$XmlNamespaceManager.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')

#endregion Add namespace manager to recognise x: tags

#region Create PS objects for controls

$GUI = @{}
$namedNodes = $XAML.SelectNodes("//*[@x:Name]",$XmlNamespaceManager)
$namedNodes | ForEach-Object -Process {$GUI.Add($_.Name, $Rawform.FindName($_.Name))}

#endregion Create PS objects for controls

#region Show the form

$showform = Read-Host -Prompt "Do you want to show the form now - $Rawform.ShowDialog() ? (Y / N)"

if ($showform -like "Y")
{
    $Rawform.ShowDialog()
}
#endregion Show the form