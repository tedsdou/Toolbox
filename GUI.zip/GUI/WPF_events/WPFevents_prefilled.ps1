﻿#region load assembly dlls

Add-Type -AssemblyName PresentationCore,PresentationFramework

#endregion load assembly dlls

#region Cleanup XAML

$XAML= [XML](Get-Content -Path "$PSScriptRoot\MainWindow.xaml" -Raw)
$XAML.Window.RemoveAttribute('x:Class')
$XAML.Window.RemoveAttribute('xmlns:local')
$XAML.Window.RemoveAttribute('xmlns:d')
$XAML.Window.RemoveAttribute('xmlns:mc')
$XAML.Window.RemoveAttribute('mc:Ignorable')

#endregion Cleanup XAML options

#region Add namespace manager to recognise x: tags
$XAMLreader = New-Object System.Xml.XmlNodeReader $XAML
$Rawform = [Windows.Markup.XamlReader]::Load($XAMLreader)

$XmlNamespaceManager = [System.Xml.XmlNamespaceManager]::New($XAML.NameTable)
$XmlNamespaceManager.AddNamespace('x','http://schemas.microsoft.com/winfx/2006/xaml')

#endregion Add namespace manager to recognise x: tags

#region Create PS objects for controls

$Gui = @{}
$namedNodes = $XAML.SelectNodes("//*[@x:Name]",$XmlNamespaceManager)
$namedNodes | ForEach-Object -Process {$Gui.Add($_.Name, $Rawform.FindName($_.Name))}

#endregion Create PS objects for controls

#region prefill form

$Gui.Inputtext.Text = "c:\temp"

1..10 | ForEach-Object -Process {$Gui.Itemlist.Items.add($_)}

$objects = "Object120","Object268","Object704“
$objects | ForEach-Object -Process {$Gui.Detaileditemlist.Items.add($_)}

#endregion prefill form

#region Show the form

$showform = Read-Host -Prompt "Do you want to show the form now - $Rawform.ShowDialog() ? (Y / N)"

if ($showform -like "Y")
{
    $Rawform.ShowDialog()
}
#endregion Show the form