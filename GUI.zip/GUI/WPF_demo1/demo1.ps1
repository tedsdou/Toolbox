﻿#region Load GUI Will be explained later in course 
Add-Type -AssemblyName presentationframework, presentationcore
$XAML = Get-Content -Path "$PSScriptRoot\GUI.xaml"
$XAML = $XAML -replace 'mc:Ignorable="d"','' -replace "x:N",'N' -replace 'x:Class=".*?"','' -replace 'd:DesignHeight="\d*?"','' -replace 'd:DesignWidth="\d*?"',''
$xaml = [xml]$XAML
$reader = New-Object System.Xml.XmlNodeReader $xaml
$tempform = [Windows.Markup.XamlReader]::Load($reader)
$wpf = @{ }
$namedNodes = $xaml.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]")
$namedNodes | ForEach-Object {$wpf.Add($_.Name, $tempform.FindName($_.Name))}
#endregion





#region codebehindButton

$codebehindButton = {
    $service = get-service $WPF["InputBox"].Text -ErrorAction SilentlyContinue
    if($service.status -eq "running")
    {
        $WPF["DisplayImage"].Source = "$PSScriptRoot\yes.png"
        
    }
    else
    {
        $WPF["DisplayImage"].Source = "$PSScriptRoot\NO.png"
    }
}

#endregion codebehindButton













#region control form
$WPF["PressButton"].add_Click($codebehindButton)
$wpf["MainWindow1"].ShowDialog() | Out-Null
#endregion control form